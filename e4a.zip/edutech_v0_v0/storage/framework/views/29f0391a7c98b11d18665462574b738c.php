<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <h1 class="text-3xl font-bold text-white">My Classes & Subjects</h1>

        <?php if($classSubjects->isEmpty()): ?>
            <div class="bg-yellow-500/10 border border-yellow-500 rounded-lg p-6">
                <p class="text-yellow-400">You haven't been assigned to any classes yet.</p>
            </div>
        <?php else: ?>
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $classSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-gray-800 hover:bg-gray-750 rounded-lg shadow-xl p-6 transition">
                        <div class="mb-4">
                            <h3 class="text-xl font-semibold text-white"><?php echo e($classSubject->subject->name); ?></h3>
                            <p class="text-sm text-gray-400"><?php echo e($classSubject->class->name); ?></p>
                            <p class="text-xs text-gray-500"><?php echo e($classSubject->class->school->name); ?></p>
                        </div>

                        <div class="flex items-center justify-between">
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-purple-500/20 text-purple-400">
                                Coefficient: <?php echo e($classSubject->coefficient); ?>

                            </span>
                            <a href="<?php echo e(route('teacher.grade-form', $classSubject->id)); ?>"
                                class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition">
                                Add Grades
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/michael/EduTech_Base_v1/edutech_v0_v0/resources/views/teacher/dashboard.blade.php ENDPATH**/ ?>