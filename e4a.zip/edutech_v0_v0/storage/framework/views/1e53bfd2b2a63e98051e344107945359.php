<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl mx-auto space-y-6">
        <div>
            <a href="<?php echo e(route('manager.classes.index')); ?>" class="text-blue-400 hover:text-blue-300">← Back to Classes</a>
            <h1 class="text-3xl font-bold text-white mt-2">Edit Class</h1>
        </div>

        <div class="bg-gray-800 rounded-lg shadow-xl p-6">
            <form method="POST" action="<?php echo e(route('manager.classes.update', $class->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Class Name -->
                <div class="mb-6">
                    <label for="name" class="block text-sm font-medium text-gray-300 mb-2">
                        Class Name <span class="text-red-400">*</span>
                    </label>
                    <input type="text" name="name" id="name" required value="<?php echo e(old('name', $class->name)); ?>"
                        class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-400 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Capacity -->
                <div class="mb-6">
                    <label for="capacity" class="block text-sm font-medium text-gray-300 mb-2">
                        Class Capacity (Optional)
                    </label>
                    <input type="number" name="capacity" id="capacity" min="1" max="100"
                        value="<?php echo e(old('capacity', $class->capacity)); ?>"
                        class="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500">
                    <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-400 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Actions -->
                <div class="flex justify-end space-x-3">
                    <a href="<?php echo e(route('manager.classes.index')); ?>"
                        class="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition">
                        Cancel
                    </a>
                    <button type="submit"
                        class="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition">
                        Update Class
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/michael/EduTech_Base_v1/edutech_v0_v0/resources/views/manager/classes/edit.blade.php ENDPATH**/ ?>